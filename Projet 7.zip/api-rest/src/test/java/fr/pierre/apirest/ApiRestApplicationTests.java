package fr.pierre.apirest;

import org.junit.Test;

public class ApiRestApplicationTests {

	public ApiRestApplicationTests() {
	}
	
	@Test
	public void contextLoads() {
	}

}
