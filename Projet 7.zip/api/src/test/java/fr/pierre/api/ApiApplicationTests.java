package fr.pierre.api;

import org.junit.jupiter.api.Test;

public class ApiApplicationTests {

	public ApiApplicationTests() {
	}
	
	@Test
	public void contextLoads() {
	}

}
