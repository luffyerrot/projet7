package fr.pierre.batch.config;

public class Info {

	public static final String mail = "projet7.opc@gmail.com";
	
	public static final String password = "Projet7Opc!";
}
