package fr.pierre.batch;

import org.junit.Test;

public class BatchApplicationTests {

	public BatchApplicationTests() {
	}
	
	@Test
	public void contextLoads() {
	}

}
